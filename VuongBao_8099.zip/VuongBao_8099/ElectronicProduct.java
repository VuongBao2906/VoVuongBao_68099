
package VuongBao_8099;
import java.util.Scanner;

public class ElectronicProduct extends Product {
    public String brand;
    public int warrantyMonths;

    public ElectronicProduct() {
        super();
    }

    public ElectronicProduct(String id, String productName, double price, boolean isAvailable, String brand, int warrantyMonths) {
        super(id, productName, price, isAvailable);
        this.brand = brand;
        this.warrantyMonths = warrantyMonths;
    }

    @Override
    public void addProductInfo() {
        super.addProductInfo();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Brand: ");
        this.brand = scanner.nextLine();
        System.out.print("Enter Warranty Months: ");
        this.warrantyMonths = Integer.parseInt(scanner.nextLine());
    }

    @Override
    public void updateProductInfo() {
        super.updateProductInfo();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Update Brand: ");
        this.brand = scanner.nextLine();
        System.out.print("Update Warranty Months: ");
        this.warrantyMonths = Integer.parseInt(scanner.nextLine());
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Brand: " + brand);
        System.out.println("Warranty Months: " + warrantyMonths + " months");
    }
}