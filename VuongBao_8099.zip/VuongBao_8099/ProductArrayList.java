
package VuongBao_8099;
import java.util.ArrayList;

public class ProductArrayList {
    public ArrayList<Product> productArrayList = new ArrayList<>();

    public void addProductInfo(Product product) {
        productArrayList.add(product);
        System.out.println("Product added successfully!");
    }

    public void updateProductById(String id) {
        for (Product product : productArrayList) {
            if (product.id.equalsIgnoreCase(id)) {
                product.updateProductInfo();
                System.out.println("Product updated successfully!");
                return;
            }
        }
        System.out.println("Product with ID " + id + " not found!");
    }

    public void deleteProductById(String id) {
        boolean removed = productArrayList.removeIf(product -> product.id.equalsIgnoreCase(id));
        if (removed) {
            System.out.println("Product deleted successfully!");
        } else {
            System.out.println("Product with ID " + id + " not found!");
        }
    }

    public void findProductById(String id) {
        for (Product product : productArrayList) {
            if (product.id.equalsIgnoreCase(id)) {
                System.out.println("--- Product Information ---");
                product.displayInfo();
                return;
            }
        }
        System.out.println("Product with ID " + id + " not found!");
    }

    public void displayAllProducts() {
        if (productArrayList.isEmpty()) {
            System.out.println("Product list is empty.");
            return;
        }
        System.out.println("=== PRODUCT LIST ===");
        for (Product product : productArrayList) {
            product.displayInfo();
            System.out.println("-------------------------");
        }
    }

    public void countProductByType() {
        int foodCount = 0;
        int electronicCount = 0;

        for (Product product : productArrayList) {
            if (product instanceof FoodProduct) {
                foodCount++;
            } else if (product instanceof ElectronicProduct) {
                electronicCount++;
            }
        }

        System.out.println("Number of Food Products: " + foodCount);
        System.out.println("Number of Electronic Products: " + electronicCount);
    }
}