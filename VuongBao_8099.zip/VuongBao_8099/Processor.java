
package VuongBao_8099;
import java.util.Scanner;

public class Processor {
    public static void main(String[] args) {
        ProductArrayList productManager = new ProductArrayList();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n========== PRODUCT MANAGEMENT ==========");
            System.out.println("1. Add Food Product");
            System.out.println("2. Add Electronic Product");
            System.out.println("3. Update Product by ID");
            System.out.println("4. Delete Product by ID");
            System.out.println("5. Find Product by ID");
            System.out.println("6. Display All Products");
            System.out.println("7. Count Products by Type");
            System.out.println("0. Exit");
            System.out.println("========================================");
            System.out.print("Your choice: ");

            try {
                choice = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                choice = -1;
            }

            switch (choice) {
                case 1:
                    System.out.println("\n--- ADD FOOD PRODUCT ---");
                    FoodProduct food = new FoodProduct();
                    food.addProductInfo();
                    productManager.addProductInfo(food);
                    break;

                case 2:
                    System.out.println("\n--- ADD ELECTRONIC PRODUCT ---");
                    ElectronicProduct electronic = new ElectronicProduct();
                    electronic.addProductInfo();
                    productManager.addProductInfo(electronic);
                    break;

                case 3:
                    System.out.print("Enter Product ID to update: ");
                    String updateId = scanner.nextLine();
                    productManager.updateProductById(updateId);
                    break;

                case 4:
                    System.out.print("Enter Product ID to delete: ");
                    String deleteId = scanner.nextLine();
                    productManager.deleteProductById(deleteId);
                    break;

                case 5:
                    System.out.print("Enter Product ID to find: ");
                    String findId = scanner.nextLine();
                    productManager.findProductById(findId);
                    break;

                case 6:
                    productManager.displayAllProducts();
                    break;

                case 7:
                    productManager.countProductByType();
                    break;

                case 0:
                    System.out.println("Thank you for using the application!");
                    break;

                default:
                    System.out.println("Invalid choice, please try again!");
            }
        } while (choice != 0);

        scanner.close();
    }
}