
package VuongBao_8099;
import java.util.Date;
import java.util.Scanner;

public class FoodProduct extends Product {
    public String category;
    public Date expiryDate;

    public FoodProduct() {
        super();
    }

    public FoodProduct(String id, String productName, double price, boolean isAvailable, String category, Date expiryDate) {
        super(id, productName, price, isAvailable);
        this.category = category;
        this.expiryDate = expiryDate;
    }

    @Override
    public void addProductInfo() {
        super.addProductInfo();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Food Category: ");
        this.category = scanner.nextLine();
        this.expiryDate = new Date(); 
    }

    @Override
    public void updateProductInfo() {
        super.updateProductInfo();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Update Food Category: ");
        this.category = scanner.nextLine();
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Category: " + category);
        System.out.println("Expiration Date: " + expiryDate);
    }
}