
package VuongBao_8099;
import java.util.Scanner;

public interface IProduct {
    void addProductInfo();
    void updateProductInfo();
    void displayInfo();
}