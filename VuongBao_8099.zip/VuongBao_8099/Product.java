
package VuongBao_8099;
import java.util.Scanner;

public abstract class Product implements IProduct {
    public String id;
    public String productName;
    public double price;
    public boolean isAvailable;

    public Product() {
    }

    public Product(String id, String productName, double price, boolean isAvailable) {
        this.id = id;
        this.productName = productName;
        this.price = price;
        this.isAvailable = isAvailable;
    }

    @Override
    public void addProductInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ID: ");
        this.id = scanner.nextLine();
        System.out.print("Enter Product Name: ");
        this.productName = scanner.nextLine();
        System.out.print("Enter Price: ");
        this.price = Double.parseDouble(scanner.nextLine());
        System.out.print("Is Available (true/false): ");
        this.isAvailable = Boolean.parseBoolean(scanner.nextLine());
    }

    @Override
    public void updateProductInfo() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Update Product Name: ");
        this.productName = scanner.nextLine();
        System.out.print("Update Price: ");
        this.price = Double.parseDouble(scanner.nextLine());
        System.out.print("Update Availability (true/false): ");
        this.isAvailable = Boolean.parseBoolean(scanner.nextLine());
    }

    @Override
    public void displayInfo() {
        System.out.println("ID: " + id);
        System.out.println("Product Name: " + productName);
        System.out.println("Price: " + price);
        System.out.println("Status: " + (isAvailable ? "In Stock" : "Out of Stock"));
    }
}